# Advent of Code

## 2015

- Python (🎄 50⭐)

## 2016

- Python (🎄 50⭐)

## 2017

- Python (🎄 50⭐)
- Bash (10⭐)

## 2018

- Python (🎄 50⭐)
- Bash (2⭐)

## 2019

- Python (🎄 50⭐)

## 2020

- Python (🎄 50⭐)
- Bash (2⭐)
