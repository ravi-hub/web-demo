DATA_DIR = '../../../data/2017'
